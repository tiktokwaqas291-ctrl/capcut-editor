package com.smalix.mobile

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.util.TypedValue

class MainActivity : Activity() {
    private lateinit var result: TextView
    private val pickApkRequest = 4101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 19, 35)
        window.navigationBarColor = Color.rgb(16, 19, 35)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(20))
            setBackgroundColor(Color.rgb(15, 18, 32))
        }

        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        val brand = TextView(this).apply {
            text = "SMALIX MOBILE"
            setTextColor(Color.rgb(129, 140, 248))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTypeface(null, Typeface.BOLD)
            letterSpacing = 0.12f
        }
        content.addView(brand)

        val title = TextView(this).apply {
            text = "APK Workbench"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 30f)
            setTypeface(null, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(6))
        }
        content.addView(title)

        val subtitle = TextView(this).apply {
            text = "Open an APK and inspect its basic package information."
            setTextColor(Color.rgb(183, 188, 207))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(0, 0, 0, dp(22))
        }
        content.addView(subtitle)

        content.addView(actionButton("📂  Open APK", true) { openApkPicker() })
        content.addView(sectionLabel("TOOLS"))
        content.addView(toolCard("APK Analyzer", "Package name, version and SDK details", "Available"))
        content.addView(toolCard("Smali Editor", "Edit disassembled bytecode", "Planned"))
        content.addView(toolCard("XML / Manifest Editor", "Inspect and edit app resources", "Planned"))
        content.addView(toolCard("Rebuild & Sign", "Build and sign a modified APK", "Planned"))
        content.addView(sectionLabel("APK DETAILS"))

        result = TextView(this).apply {
            text = "No APK selected yet."
            setTextColor(Color.rgb(210, 214, 230))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.rgb(29, 34, 54))
        }
        content.addView(result)

        val note = TextView(this).apply {
            text = "Starter build • Decompiling, editing, rebuilding and signing engines are not integrated yet."
            setTextColor(Color.rgb(145, 151, 174))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, dp(18), 0, dp(8))
        }
        content.addView(note)

        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun openApkPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, pickApkRequest)
    }

    @Deprecated("Deprecated by Android, kept for compatibility with this small starter")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickApkRequest || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        inspectApk(uri)
    }

    private fun inspectApk(uri: Uri) {
        try {
            val localPath = cacheDir.absolutePath + "/selected.apk"
            contentResolver.openInputStream(uri).use { input ->
                if (input == null) throw IllegalStateException("Could not open selected file.")
                java.io.FileOutputStream(localPath).use { output -> input.copyTo(output) }
            }

            val flags = PackageManager.GET_ACTIVITIES or PackageManager.GET_PERMISSIONS
            val info: PackageInfo? = if (Build.VERSION.SDK_INT >= 33) {
                packageManager.getPackageArchiveInfo(localPath, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                packageManager.getPackageArchiveInfo(localPath, flags)
            }

            if (info == null) {
                result.text = "Android could not read this APK's package metadata. The file may be damaged or not a valid APK."
                return
            }

            val appInfo = info.applicationInfo
            val versionName = if (Build.VERSION.SDK_INT >= 28) info.longVersionCode.toString() else info.versionCode.toString()
            val minSdk = try { appInfo?.minSdkVersion?.toString() ?: "Unknown" } catch (_: Exception) { "Unknown" }
            val permissions = info.requestedPermissions?.joinToString("\n") ?: "No permissions listed"

            result.text = "File: ${uri.lastPathSegment ?: "selected APK"}\n\nPackage: ${info.packageName}\nVersion name: ${info.versionName ?: "Unknown"}\nVersion code: $versionName\nMin SDK: $minSdk\n\nRequested permissions:\n$permissions"
        } catch (e: Exception) {
            result.text = "Could not inspect APK.\n${e.message ?: "Unknown error"}"
        }
    }

    private fun sectionLabel(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(Color.rgb(145, 151, 174))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        setTypeface(null, Typeface.BOLD)
        setPadding(0, dp(24), 0, dp(10))
    }

    private fun toolCard(name: String, description: String, status: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            setBackgroundColor(Color.rgb(29, 34, 54))
        }
        val heading = TextView(this).apply {
            text = "$name   •   $status"
            setTextColor(if (status == "Available") Color.rgb(134, 239, 172) else Color.rgb(253, 211, 120))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTypeface(null, Typeface.BOLD)
        }
        val detail = TextView(this).apply {
            text = description
            setTextColor(Color.rgb(183, 188, 207))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(5), 0, 0)
        }
        box.addView(heading)
        box.addView(detail)
        val params = LinearLayout.LayoutParams(-1, -2)
        params.bottomMargin = dp(9)
        box.layoutParams = params
        return box
    }

    private fun actionButton(label: String, primary: Boolean, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(if (primary) Color.rgb(91, 103, 241) else Color.rgb(44, 50, 76))
            textSize = 16f
            setOnClickListener { action() }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
